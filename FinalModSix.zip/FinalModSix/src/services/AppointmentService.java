//AppointmentService.java
package services;


import java.util.ArrayList;
import java.util.List;

public class AppointmentService {
 private final List<Appointment> appointments;

 public AppointmentService() {
     this.appointments = new ArrayList<>();
 }

 /**
  * Adds a new appointment with a unique appointment ID.
  * Throws IllegalArgumentException if an appointment with the same ID already exists.
  */
 public void addAppointment(Appointment appointment) {
     if (appointment == null) {
         throw new IllegalArgumentException("Appointment cannot be null.");
     }

     for (Appointment existing : appointments) {
         if (existing.getAppointmentId().equals(appointment.getAppointmentId())) {
             throw new IllegalArgumentException(
                 "Appointment ID must be unique. ID already exists: " + appointment.getAppointmentId()
             );
         }
     }

     appointments.add(appointment);
 }

 /**
  * Deletes an appointment by its appointment ID.
  * Returns true if deleted, false if no appointment with that ID was found.
  */
 public boolean deleteAppointment(String appointmentId) {
     if (appointmentId == null || appointmentId.isEmpty()) {
         throw new IllegalArgumentException("Appointment ID cannot be null or empty.");
     }

     return appointments.removeIf(appointment -> 
         appointment.getAppointmentId().equals(appointmentId)
     );
 }

 /**
  * Retrieves all appointments (useful for testing)
  */
 public List<Appointment> getAllAppointments() {
     return new ArrayList<>(appointments); // Return a copy to protect encapsulation
 }
}