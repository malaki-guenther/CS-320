package services;

import java.util.ArrayList;
import java.util.List;

public class TaskService {
    private final List<Task> tasks;

    public TaskService() {
        this.tasks = new ArrayList<>();
    }

    // Add a new task with a unique ID
    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null.");
        }
        for (Task existingTask : tasks) {
            if (existingTask.getTaskId().equals(task.getTaskId())) {
                throw new IllegalArgumentException("Task ID must be unique.");
            }
        }
        tasks.add(task);
    }

    // Delete a task by taskId
    public void deleteTask(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("Task ID cannot be null.");
        }
        tasks.removeIf(task -> task.getTaskId().equals(taskId));
    }

    // Update name of a task by taskId
    public void updateTaskName(String taskId, String newName) {
        if (taskId == null || newName == null || newName.length() > 20) {
            throw new IllegalArgumentException("Invalid task ID or name.");
        }
        for (Task task : tasks) {
            if (task.getTaskId().equals(taskId)) {
                task.setName(newName);
                return;
            }
        }
        throw new IllegalArgumentException("Task with ID " + taskId + " not found.");
    }

    // Update description of a task by taskId
    public void updateTaskDescription(String taskId, String newDescription) {
        if (taskId == null || newDescription == null || newDescription.length() > 50) {
            throw new IllegalArgumentException("Invalid task ID or description.");
        }
        for (Task task : tasks) {
            if (task.getTaskId().equals(taskId)) {
                task.setDescription(newDescription);
                return;
            }
        }
        throw new IllegalArgumentException("Task with ID " + taskId + " not found.");
    }

    // Helper method to get task list (used only for testing)
    public List<Task> getTasks() {
        return tasks;
    }
}