// src/test/java/AppointmentTest.java
package testCases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;
import services.Appointment;

public class AppointmentTest {

    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, 1);
        return cal.getTime();
    }

    private Date getPastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, -1);
        return cal.getTime();
    }

    @Test
    @DisplayName("Appointment constructor accepts valid data")
    void testAppointmentValid() {
        Appointment appt = new Appointment("1234567890", getFutureDate(), "Regular checkup");
        assertAll(
            () -> assertEquals("1234567890", appt.getAppointmentId()),
            () -> assertEquals("Regular checkup", appt.getDescription()),
            () -> assertNotNull(appt.getAppointmentDate())
        );
    }

    @Test
    @DisplayName("Appointment ID cannot be null")
    void testAppointmentIdNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(null, getFutureDate(), "Desc"));
    }

    @Test
    @DisplayName("Appointment ID cannot be longer than 10 characters")
    void testAppointmentIdTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("12345678901", getFutureDate(), "Desc"));
    }

    @Test
    @DisplayName("Appointment date cannot be null")
    void testAppointmentDateNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("123", null, "Desc"));
    }

    @Test
    @DisplayName("Appointment date cannot be in the past")
    void testAppointmentDateInPast() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("123", getPastDate(), "Desc"));
    }

    @Test
    @DisplayName("Appointment description cannot be null")
    void testDescriptionNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("123", getFutureDate(), null));
    }

    @Test
    @DisplayName("Appointment description cannot be longer than 50 characters")
    void testDescriptionTooLong() {
        String longDesc = "A".repeat(51);
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("123", getFutureDate(), longDesc));
    }

    @Test
    @DisplayName("setAppointmentDate accepts future date")
    void testSetFutureDate() {
        Appointment appt = new Appointment("123", getFutureDate(), "Desc");
        Date evenLater = getFutureDate();
        ((Calendar) Calendar.getInstance()).add(Calendar.YEAR, 2);
        appt.setAppointmentDate(evenLater);
        assertEquals(evenLater, appt.getAppointmentDate());
    }

    @Test
    @DisplayName("setAppointmentDate rejects past date")
    void testSetPastDate() {
        Appointment appt = new Appointment("123", getFutureDate(), "Desc");
        assertThrows(IllegalArgumentException.class, () ->
            appt.setAppointmentDate(getPastDate()));
    }

    @Test
    @DisplayName("setDescription accepts valid description")
    void testSetValidDescription() {
        Appointment appt = new Appointment("123", getFutureDate(), "Old");
        appt.setDescription("New valid description");
        assertEquals("New valid description", appt.getDescription());
    }

    @Test
    @DisplayName("setDescription rejects too-long description")
    void testSetDescriptionTooLong() {
        Appointment appt = new Appointment("123", getFutureDate(), "Old");
        String longDesc = "A".repeat(51);
        assertThrows(IllegalArgumentException.class, () ->
            appt.setDescription(longDesc));
    }
}