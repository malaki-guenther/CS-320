package testCases;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import services.TaskService;
import services.Task;

public class TaskServiceTest {
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTaskSuccess() {
        Task task = new Task("12345", "Finish Project", "Complete milestone");
        taskService.addTask(task);
        assertEquals(1, taskService.getTasks().size());
    }

    @Test
    public void testAddTaskDuplicateIdThrowsException() {
        Task task1 = new Task("123", "Task One", "First task");
        Task task2 = new Task("123", "Task Two", "Second task");
        taskService.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task2));
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("999", "Delete Me", "Should be removed");
        taskService.addTask(task);
        taskService.deleteTask("999");
        assertEquals(0, taskService.getTasks().size());
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("ABC123", "Old Name", "Old description");
        taskService.addTask(task);
        taskService.updateTaskName("ABC123", "New Name");
        Task updated = taskService.getTasks().get(0);
        assertEquals("New Name", updated.getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("XYZ789", "Name", "Old desc");
        taskService.addTask(task);
        taskService.updateTaskDescription("XYZ789", "New detailed description here");
        Task updated = taskService.getTasks().get(0);
        assertEquals("New detailed description here", updated.getDescription());
    }

    @Test
    public void testUpdateNonExistentTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskName("NONEXIST", "Test"));
    }
}
