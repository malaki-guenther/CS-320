// src/test/java/AppointmentServiceTest.java
package testCases;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;
import services.AppointmentService;
import services.Appointment;

public class AppointmentServiceTest {

    private AppointmentService service;
    private Date futureDate;

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, 5);
        futureDate = cal.getTime();
    }

    private Appointment createValidAppointment(String id) {
        return new Appointment(id, futureDate, "Description for " + id);
    }

    @Test
    @DisplayName("addAppointment adds a new appointment")
    void testAddAppointment() {
        Appointment appt = createValidAppointment("APP001");
        service.addAppointment(appt);
        // We can't access the map directly, so we rely on no exception + duplicate test below
        assertThrows(IllegalArgumentException.class, () ->
            service.addAppointment(createValidAppointment("APP001")));
    }

    @Test
    @DisplayName("addAppointment rejects duplicate ID")
    void testAddDuplicateId() {
        service.addAppointment(createValidAppointment("DUP123"));
        assertThrows(IllegalArgumentException.class, () ->
            service.addAppointment(createValidAppointment("DUP123")));
    }

    @Test
    @DisplayName("addAppointment rejects null appointment")
    void testAddNullAppointment() {
        assertThrows(IllegalArgumentException.class, () ->
            service.addAppointment(null));
    }

    @Test
    @DisplayName("deleteAppointment removes existing appointment")
    void testDeleteExisting() {
        Appointment appt = createValidAppointment("DEL001");
        service.addAppointment(appt);
        service.deleteAppointment("DEL001");
        // Trying to add it again proves it was really removed
        service.addAppointment(appt); // should succeed now
    }

    @Test
    @DisplayName("deleteAppointment with non-existent ID does nothing (no exception)")
    void testDeleteNonExistent() {
        assertDoesNotThrow(() -> service.deleteAppointment("NONEXISTENT"));
    }

    @Test
    @DisplayName("deleteAppointment rejects null ID")
    void testDeleteNullId() {
        assertThrows(IllegalArgumentException.class, () ->
            service.deleteAppointment(null));
    }

    @Test
    @DisplayName("Multiple appointments can be added with unique IDs")
    void testMultipleAppointments() {
        service.addAppointment(createValidAppointment("A1"));
        service.addAppointment(createValidAppointment("A2"));
        service.addAppointment(createValidAppointment("A3"));

        // Try adding them again → all should fail
        assertAll(
            () -> assertThrows(IllegalArgumentException.class, () -> service.addAppointment(createValidAppointment("A1"))),
            () -> assertThrows(IllegalArgumentException.class, () -> service.addAppointment(createValidAppointment("A2"))),
            () -> assertThrows(IllegalArgumentException.class, () -> service.addAppointment(createValidAppointment("A3")))
        );
    }
}