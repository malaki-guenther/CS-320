package testCases;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import services.Task;

public class TaskTest {

    // Successful creation
    @Test
    public void testTaskCreationSuccess() {
        Task task = new Task("1234567890", "Valid Name", "Valid description under fifty chars");
        assertNotNull(task);
        assertEquals("1234567890", task.getTaskId());
        assertEquals("Valid Name", task.getName());
        assertEquals("Valid description under fifty chars", task.getDescription());
    }

    // Task ID tests
    @Test
    public void testTaskIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Description");
        });
    }

    @Test
    public void testTaskIdCannotExceed10Characters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Description"); // 11 chars
        });
    }

    // Name tests
    @Test
    public void testNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", null, "Description");
        });
    }

    @Test
    public void testNameCannotExceed20Characters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "This name is way too long for the limit", "Desc");
        });
    }

    // Description tests
    @Test
    public void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Name", null);
        });
    }

    @Test
    public void testDescriptionCannotExceed50Characters() {
        String fiftyOne = "A".repeat(51);
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Name", fiftyOne);
        });
    }

    // Task ID is immutable (no setter)
    @Test
    public void testTaskIdIsNotUpdatable() {
        Task task = new Task("ORIGINAL", "Name", "Desc");
        // There is intentionally no setTaskId() method
        // This compile-time check proves it cannot be updated
        assertEquals("ORIGINAL", task.getTaskId());
    }

    // Updating name and description works
    @Test
    public void testUpdateNameAndDescription() {
        Task task = new Task("12345", "Old Name", "Old Desc");
        task.setName("New Name");
        task.setDescription("Brand new description");
        assertEquals("New Name", task.getName());
        assertEquals("Brand new description", task.getDescription());
    }
}